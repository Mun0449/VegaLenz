from .compare_Keywords import check_keywords
from .logger import get_logger,  get_logger_by_name
from .choiceLogic import choice
from .detectBlock import detect_text_blocks, flatten_crops